import java.io.FileInputStream;
import java.io.ObjectInputStream;
import smile.classification.RandomForest;
import smile.data.Tuple;
import smile.data.type.DataTypes;
import smile.data.type.StructField;
import smile.data.type.StructType;

public class TestModel {

  public static void main(String[] args) {
    String modelPath = "driverPredictionModel.ser";
    System.out.println("=== Loading Model to Memory ===");

    RandomForest model;
    try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(modelPath))) {
      model = (RandomForest) ois.readObject();
      System.out.println("Model loaded successfully from: " + modelPath);
    } catch (Exception e) {
      System.err.println("CRITICAL ERROR: Could not load the model file!");
      return;
    }

    // Updated 13-Feature Schema Contract
    StructType schema = new StructType(new StructField[] {
        new StructField("experiencia_anios", DataTypes.DoubleType),
        new StructField("total_ordenes", DataTypes.DoubleType), // Added back
        new StructField("tasa_exito_total", DataTypes.DoubleType),
        new StructField("tasa_exito_largas", DataTypes.DoubleType),
        new StructField("tasa_exito_medias", DataTypes.DoubleType),
        new StructField("tasa_exito_cortas", DataTypes.DoubleType),
        new StructField("tasa_exito_pesadas", DataTypes.DoubleType),
        new StructField("tasa_exito_livianas", DataTypes.DoubleType),
        new StructField("es_larga", DataTypes.DoubleType),
        new StructField("es_media", DataTypes.DoubleType),
        new StructField("es_corta", DataTypes.DoubleType),
        new StructField("es_pesada", DataTypes.DoubleType),
        new StructField("es_liviana", DataTypes.DoubleType)
    });

    System.out.println("\n=== Running Mock Simulation Scenarios ===");
    System.out.println("------------------------------------------------------------------");

    // Features: [exp, total_orders, total_rate, long_rate, med_rate, short_rate, heavy_rate, light_rate, es_larga, es_media, es_corta, es_pesada, es_liviana]
    
    // 1. Veteran Master - 1200 orders, stellar record
    double[] veteranVsNightmare = { 22.5, 1200.0, 0.95, 0.95, 0.90, 0.95, 0.96, 0.98, 1.0, 0.0, 0.0, 1.0, 0.0 };

    // 2. Lucky Rookie - Only 12 trips under their belt, terrible rates on hard tasks
    double[] rookieVsNightmare = { 0.8, 12.0, 0.45, 0.30, 0.50, 0.60, 0.20, 0.70, 1.0, 0.0, 0.0, 1.0, 0.0 };

    // 3. Same Rookie vs Safe Local Run
    double[] rookieVsEasyCity = { 0.8, 12.0, 0.45, 0.30, 0.50, 0.60, 0.20, 0.70, 0.0, 0.0, 1.0, 0.0, 1.0 };

    // 4. Standard 5-Yr Driver - 240 trips, highly stable mid-tier profile
    double[] midTierVsMediumCargo = { 5.2, 240.0, 0.82, 0.70, 0.82, 0.88, 0.75, 0.85, 0.0, 1.0, 0.0, 0.0, 1.0 };

    // 5. Experienced Driver (12yr) - 600 trips
    double[] experiencedVsChallenge = { 12.0, 600.0, 0.88, 0.80, 0.85, 0.92, 0.88, 0.90, 1.0, 0.0, 0.0, 1.0, 0.0 };

    // 6. Mediocre Driver (3yr) - 90 trips
    double[] mediocreVsLocal = { 3.0, 90.0, 0.65, 0.50, 0.65, 0.75, 0.60, 0.70, 0.0, 0.0, 1.0, 0.0, 1.0 };

    // 7. Gunslinger Mid-Tier - 180 trips, aggressive but experienced
    double[] gunslingerVsBorderline = { 3.5, 180.0, 0.75, 0.60, 0.80, 0.90, 0.55, 0.88, 1.0, 0.0, 0.0, 1.0, 0.0 };

    // 8. Burnt-Out Veteran - 900 trips, extensive history but completely failing recently
    double[] exhaustedVeteran = { 15.0, 900.0, 0.54, 0.50, 0.90, 0.95, 0.70, 0.85, 1.0, 0.0, 0.0, 1.0, 0.0 };

    // Execute
    evaluate(model, schema, "1. Veteran Master vs 55hr Extreme Heavy Haul", veteranVsNightmare);
    evaluate(model, schema, "2. Rookie vs 55hr Extreme Heavy Haul", rookieVsNightmare);
    evaluate(model, schema, "3. Rookie vs Quick & Light Local City Run", rookieVsEasyCity);
    evaluate(model, schema, "4. Standard 5-Yr Driver vs Medium Regional Cargo", midTierVsMediumCargo);
    evaluate(model, schema, "5. Experienced Driver (12yr) on Heavy Long Haul", experiencedVsChallenge);
    evaluate(model, schema, "6. Mediocre Driver (3yr) on Light Local Runs", mediocreVsLocal);
    evaluate(model, schema, "7. Gunslinger Mid-Tier vs Borderline Haul", gunslingerVsBorderline);
    evaluate(model, schema, "8. Burnt-Out Veteran vs Extreme Endurance", exhaustedVeteran);
  }

  private static void evaluate(RandomForest model, StructType schema, String scenarioName, double[] features) {
    Tuple mockTuple = Tuple.of(schema, features);
    double[] posteriori = new double[2];

    int predictionClass = model.predict(mockTuple, posteriori);
    double successProbability = posteriori[1] * 100.0;

    System.out.printf("Scenario   : %s%n", scenarioName);
    System.out.printf("Prediction : %s%n", (predictionClass == 1 ? "✔ SUCCESSFUL ARRIVAL" : "❌ HIGH RISK OF FAILURE"));
    System.out.printf("Confidence : %.2f%% probability of operational success.%n", successProbability);
    System.out.println("------------------------------------------------------------------");
  }
}