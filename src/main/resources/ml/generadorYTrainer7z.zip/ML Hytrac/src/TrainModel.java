import smile.classification.RandomForest;
import smile.data.DataFrame;
import smile.data.Tuple;
import smile.data.formula.Formula;
import smile.data.vector.DoubleVector;
import smile.io.Read;
import smile.validation.metric.Accuracy;

import org.apache.commons.csv.CSVFormat;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Paths;

import java.io.ObjectOutputStream;
import java.io.FileOutputStream;

public class TrainModel {

  public static void main(String[] args) throws IOException, URISyntaxException {

    // 1. Load the freshly regenerated dataset
    DataFrame df = Read.csv(
        Paths.get("data/dataset_entrenamiento.csv").toString(),
        CSVFormat.DEFAULT.withFirstRecordAsHeader());

    System.out.println("Raw dataset loaded: " + df.size() + " rows");

    // 2. FEATURE ENGINEERING LAYER
    System.out.println("\nEngineering behavioral ratios and explicit order flags...");
    int n = df.size();

    // Volume Metric (Converted to double for scale conformity)
    double[] totalOrdenesDouble = new double[n];

    // Historical Ratios
    double[] tasaExitoTotal = new double[n];
    double[] tasaExitoLargas = new double[n];
    double[] tasaExitoMedias = new double[n];
    double[] tasaExitoCortas = new double[n];
    double[] tasaExitoPesadas = new double[n];
    double[] tasaExitoLivianas = new double[n];

    // Current Order Explicit Flags (Matching Python Logic)
    double[] esLarga = new double[n];
    double[] esMedia = new double[n];
    double[] esCorta = new double[n];
    double[] esPesada = new double[n];
    double[] esLiviana = new double[n];

    for (int i = 0; i < n; i++) {
      Tuple row = df.get(i);

      // Extract raw data fields
      int total = row.getInt("total_ordenes");
      int largas = row.getInt("largas");
      int medias = row.getInt("medias");
      int cortas = row.getInt("cortas");
      int pesadas = row.getInt("pesadas");
      int livianas = row.getInt("livianas");

      int largasOk = row.getInt("largas_exitosas");
      int mediasOk = row.getInt("medias_exitosas");
      int cortasOk = row.getInt("cortas_exitosas");
      int pesadasOk = row.getInt("pesadas_exitosas");
      int livianasOk = row.getInt("livianas_exitosas");

      // Save volume metric as continuous double
      totalOrdenesDouble[i] = (double) total;

      // Calculate Historical Rates
      int totalExitos = largasOk + mediasOk + cortasOk;
      tasaExitoTotal[i] = total > 0 ? (double) totalExitos / total : 0.5;

      tasaExitoLargas[i] = largas > 0 ? (double) largasOk / largas : 0.5;
      tasaExitoMedias[i] = medias > 0 ? (double) mediasOk / medias : 0.5;
      tasaExitoCortas[i] = cortas > 0 ? (double) cortasOk / cortas : 0.5;
      tasaExitoPesadas[i] = pesadas > 0 ? (double) pesadasOk / pesadas : 0.5;
      tasaExitoLivianas[i] = livianas > 0 ? (double) livianasOk / livianas : 0.5;

      // Calculate Explicit Flags for the Current Order Context
      double tiempo = row.getDouble("tiempo_efectivo_orden");
      double peso = row.getDouble("peso_orden");

      esLarga[i] = (tiempo >= 8.0) ? 1.0 : 0.0;
      esMedia[i] = (tiempo >= 4.0 && tiempo < 8.0) ? 1.0 : 0.0;
      esCorta[i] = (tiempo < 4.0) ? 1.0 : 0.0;
      esPesada[i] = (peso >= 15000.0) ? 1.0 : 0.0;
      esLiviana[i] = (peso < 15000.0) ? 1.0 : 0.0;
    }

    // 1. Create the vector using the FINAL name "total_ordenes" right away
    DataFrame engineeredColumns = new DataFrame(
        new DoubleVector("total_ordenes", totalOrdenesDouble), // Named cleanly from the start
        new DoubleVector("tasa_exito_total", tasaExitoTotal),
        new DoubleVector("tasa_exito_largas", tasaExitoLargas),
        new DoubleVector("tasa_exito_medias", tasaExitoMedias),
        new DoubleVector("tasa_exito_cortas", tasaExitoCortas),
        new DoubleVector("tasa_exito_pesadas", tasaExitoPesadas),
        new DoubleVector("tasa_exito_livianas", tasaExitoLivianas),
        new DoubleVector("es_larga", esLarga),
        new DoubleVector("es_media", esMedia),
        new DoubleVector("es_corta", esCorta),
        new DoubleVector("es_pesada", esPesada),
        new DoubleVector("es_liviana", esLiviana));

    // 2. Drop the original raw integer "total_ordenes" from the base dataframe
    // BEFORE merging
    // This avoids a duplicate column conflict!
    df = df.drop("total_ordenes");

    // 3. Merge the new double-based features into the main dataframe
    df = df.merge(engineeredColumns);

    // 4. Drop the remaining raw historical counts and order contexts
    String target = "exito";
    df = df.drop("largas", "largas_exitosas", "medias", "medias_exitosas",
        "cortas", "cortas_exitosas", "pesadas", "pesadas_exitosas", "livianas", "livianas_exitosas",
        "tiempo_efectivo_orden", "peso_orden");

    System.out.println("\n=== Fully Optimized Schema ===");
    System.out.println(df.schema());

    Formula formula = Formula.lhs(target);

    System.out.println("\nTraining Random Forest...");
    RandomForest model = RandomForest.fit(formula, df);

    System.out.println("\n=== Model Metrics ===");
    System.out.println(model.metrics());

    String[] featureNames = df.drop(target).names();
    double[] importance = model.importance();

    System.out.println("\n=== Feature Importance ===");
    for (int i = 0; i < importance.length; i++) {
      if (i < featureNames.length) {
        System.out.printf("%-22s : %.4f%n", featureNames[i], importance[i]);
      }
    }

    int[] predictions = model.predict(df);
    int[] actual = df.column(target).toIntArray();
    double accuracy = Accuracy.of(actual, predictions);

    System.out.println("\nTraining Accuracy: " +
        String.format("%.4f", accuracy) +
        " (" + String.format("%.2f", accuracy * 100) + "%)");

    // SAVE MODEL OBJECT TO FILE SYSTEM
    try (ObjectOutputStream oos = new ObjectOutputStream(
        new FileOutputStream("driverPredictionModel.ser"))) {
      oos.writeObject(model);
      System.out.println("\nModel successfully saved to driverPredictionModel.ser");
    }

    // ==========================================
    // MOCK PREDICTION WITH EXTENDED EXPLICIT SCHEMA
    // ==========================================
    System.out.println("\n=== Running Mock Prediction ===");

    double mockTiempo = 12.5;
    double mockPeso = 1500.0;

    // Aligned to match the precise 13-column signature:
    Object[] mockDriverFeatures = new Object[] {
        5.0, // experiencia_anios
        140.0, // total_ordenes (Added volume metric!)
        0.85, // tasa_exito_total
        0.75, // tasa_exito_largas
        0.87, // tasa_exito_medias
        0.95, // tasa_exito_cortas
        0.70, // tasa_exito_pesadas
        0.98, // tasa_exito_livianas
        (mockTiempo >= 8.0) ? 1.0 : 0.0, // es_larga
        (mockTiempo >= 4.0 && mockTiempo < 8.0) ? 1.0 : 0.0, // es_media
        (mockTiempo < 4.0) ? 1.0 : 0.0, // es_corta
        (mockPeso >= 15000.0) ? 1.0 : 0.0, // es_pesada
        (mockPeso < 15000.0) ? 1.0 : 0.0 // es_liviana
    };

    Tuple mockTuple = Tuple.of(formula.x(df).schema(), mockDriverFeatures);
    double[] posteriori = new double[2];
    model.predict(mockTuple, posteriori);

    double successProbability = posteriori[1] * 100;
    System.out.printf("Mock Driver Evaluation Result: %.2f%% chance of success.%n", successProbability);
  }
}