import numpy as np
import pandas as pd

np.random.seed(42)

# Cargar los choferes
df_choferes = pd.read_csv("flota_choferes.csv")

def generar_ordenes_chofer(row, seed=None):
    if seed is not None:
        np.random.seed(seed)
    
    exp = row["experiencia_anios"]
    fiab = row["fiabilidad"]
    afin_larga = row["afinidad_larga_distancia"]
    afin_pesada = row["afinidad_carga_pesada"]
    impru = row["factor_imprudencia"]
    
    # ==================== SCORE GENERAL DEL CHOFER ====================
    score = (exp * 2.3) + (fiab * 48) + ((1 - impru) * 28) + (afin_larga * 10) + (afin_pesada * 8)
    score = np.clip(score, 28, 97)   # entre 28 y 97 puntos
    
    # ==================== CANTIDAD TOTAL DE ÓRDENES ====================
    total_ordenes = int(np.random.normal(exp * 13 + 75, 48))
    total_ordenes = np.clip(total_ordenes, 45, 480)
    
    # ==================== DISTRIBUCIÓN DE TIPOS ====================
    prob_larga = np.clip(0.22 + (afin_larga - 0.5) * 0.38, 0.12, 0.58)
    prob_corta = np.clip(0.38 + (1 - afin_larga) * 0.32, 0.28, 0.62)
    prob_media = 1.0 - prob_larga - prob_corta
    
    prob_pesada = np.clip(0.42 + (afin_pesada - 0.5) * 0.36, 0.28, 0.72)
    prob_liviana = 1 - prob_pesada
    
    # ==================== PROBABILIDAD DE ÉXITO POR TIPO ====================
    # Base + Score
    p_corta  = 0.935 + (score / 100) * 0.055
    p_media  = 0.82  + (score / 100) * 0.14
    p_larga  = 0.68  + (score / 100) * 0.22
    
    # Afinidad sutil
    p_larga  *= (0.94 + (afin_larga * 0.12))
    
    # Penalidad por imprudencia (afecta más en largas)
    p_larga  *= (1 - impru * 0.45)
    p_media  *= (1 - impru * 0.28)
    p_corta  *= (1 - impru * 0.12)
    
    # Penalidad por carga pesada
    p_pesada = 0.89   # multiplicador
    
    p_corta = np.clip(p_corta, 0.68, 0.99)
    p_media = np.clip(p_media, 0.52, 0.96)
    p_larga = np.clip(p_larga, 0.38, 0.93)
    
    # Generar tipos
    tipos_dist = np.random.choice(['larga', 'media', 'corta'], size=total_ordenes, p=[prob_larga, prob_media, prob_corta])
    tipos_peso = np.random.choice(['pesada', 'liviana'], size=total_ordenes, p=[prob_pesada, prob_liviana])
    
    exitosas = np.zeros(total_ordenes, dtype=bool)
    
    for i in range(total_ordenes):
        if tipos_dist[i] == 'corta':
            p = p_corta
        elif tipos_dist[i] == 'media':
            p = p_media
        else:
            p = p_larga
            
        if tipos_peso[i] == 'pesada':
            p *= p_pesada
            
        exitosas[i] = np.random.rand() < p
    
    # Contadores
    largas = np.sum(tipos_dist == 'larga')
    medias = np.sum(tipos_dist == 'media')
    cortas = np.sum(tipos_dist == 'corta')
    
    pesadas = np.sum(tipos_peso == 'pesada')
    livianas = total_ordenes - pesadas
    
    largas_ok = np.sum((tipos_dist == 'larga') & exitosas)
    medias_ok = np.sum((tipos_dist == 'media') & exitosas)
    cortas_ok = np.sum((tipos_dist == 'corta') & exitosas)
    
    pesadas_ok = np.sum((tipos_peso == 'pesada') & exitosas)
    livianas_ok = np.sum((tipos_peso == 'liviana') & exitosas)
    
    return {
        "conductor_id": row["conductor_id"],
        "total_ordenes": int(total_ordenes),
        "largas": int(largas), "largas_exitosas": int(largas_ok),
        "medias": int(medias), "medias_exitosas": int(medias_ok),
        "cortas": int(cortas), "cortas_exitosas": int(cortas_ok),
        "pesadas": int(pesadas), "pesadas_exitosas": int(pesadas_ok),
        "livianas": int(livianas), "livianas_exitosas": int(livianas_ok)
    }


# ===================== GENERAR DATASET DE ÓRDENES =====================
print("Generando órdenes por chofer...")

data_ordenes = []
for idx, row in df_choferes.iterrows():
    resultado = generar_ordenes_chofer(row, seed=idx)   # seed por chofer para reproducibilidad
    data_ordenes.append(resultado)

df_ordenes = pd.DataFrame(data_ordenes)

# Guardar
df_ordenes.to_csv("stats_choferes.csv", index=False, encoding='utf-8')

print(f"✅ Archivo generado: ordenes_choferes.csv")
print(f"Total de choferes procesados: {len(df_ordenes)}")
print(f"Total de órdenes simuladas: {df_ordenes['total_ordenes'].sum():,}")

# Mostrar ejemplo
print("\nEjemplo de las primeras 5 filas:")
print(df_ordenes.head())