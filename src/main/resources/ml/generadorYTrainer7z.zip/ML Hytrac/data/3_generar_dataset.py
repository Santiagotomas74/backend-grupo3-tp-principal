import random
import numpy as np
import pandas as pd

# ============================================================
# CONFIG
# ============================================================

INPUT_FLOTA = "data\\flota_choferes.csv"
INPUT_STATS = "data\\stats_choferes.csv"
OUTPUT_DATASET = "data\\dataset_entrenamiento.csv"

NUM_SAMPLES = 100000

random.seed(42)
np.random.seed(42)

# ============================================================
# LOAD DATA
# ============================================================

flota_df = pd.read_csv(INPUT_FLOTA)
stats_df = pd.read_csv(INPUT_STATS)

# Merge properly using native keys
drivers_df = pd.merge(
    flota_df,
    stats_df,
    on="conductor_id",
    suffixes=("_flota", "_stats")
)

print(f"Choferes cargados: {len(drivers_df)}")

# ============================================================
# HELPERS
# ============================================================

def safe_rate(successes, total):
    if total <= 0:
        return 0.5
    return successes / total


def generate_order_context(es_era_oscura, driver_experiencia):
    """
    Handles both competent routing and the owner's son's chaotic assignments.
    Ensures travel times scale up to 54-55 hours (Jujuy to Río Gallegos limit).
    """
    MAX_TIEMPO_RUTA = 55.0
    
    if es_era_oscura:
        # The owner's son makes completely random assignments (Generates our failure cases)
        tiempo = random.uniform(1.0, MAX_TIEMPO_RUTA)
        peso = random.uniform(200.0, 45000.0)
    else:
        # Competent Administration Routing (Selection Bias Engine)
        if random.random() < 0.70:
            # 70% Regional/Local Standard Cargo
            tiempo = random.uniform(1.0, 7.99)
            peso = random.uniform(200.0, 14999.9)
        else:
            # 30% Long-haul interstate shipments
            tiempo = random.uniform(8.0, MAX_TIEMPO_RUTA)
            peso = random.uniform(15000.0, 45000.0)
            
            # Smart filter: Keep rookies off extreme long/heavy trips
            if driver_experiencia < 3.0:
                tiempo = random.uniform(1.0, 4.0)
                peso = random.uniform(200.0, 12000.0)

    return tiempo, peso


def compute_success_probability(driver, tiempo, peso):
    # System Constants for Continuous Gradients
    CAPACIDAD_MAX_PESO = 45000.0
    MAX_TIEMPO_RUTA = 55.0

    total_viajes = (driver["largas"] + driver["medias"] + driver["cortas"])
    total_exitos = (driver["largas_exitosas"] + driver["medias_exitosas"] + driver["cortas_exitosas"])

    overall_rate = safe_rate(total_exitos, total_viajes)
    short_rate   = safe_rate(driver["cortas_exitosas"], driver["cortas"])
    medium_rate  = safe_rate(driver["medias_exitosas"], driver["medias"])
    long_rate    = safe_rate(driver["largas_exitosas"], driver["largas"])
    light_rate   = safe_rate(driver["livianas_exitosas"], driver["livianas"])
    heavy_rate   = safe_rate(driver["pesadas_exitosas"], driver["pesadas"])

    # Extract hidden phenotypic traits
    fiab        = driver["fiabilidad"]
    afin_larga  = driver["afinidad_larga_distancia"]
    afin_pesada = driver["afinidad_carga_pesada"]
    impru       = driver["factor_imprudencia"]
    experiencia = driver["experiencia_anios"]

    # --------------------------------------------------------
    # 1. Base Probability & Smooth Gradients
    # --------------------------------------------------------
    p = 0.50  # Balanced baseline center point
    
    # Experience gives a nice bonus, but it can NO LONGER single-handedly save a terrible driver
    p += (min(experiencia, 15.0) / 15.0) * 0.15

    # --- ANTI-FEATURE DOMINANCE FIX ---
    # Overriding global traits with structural operational performance history.
    if overall_rate < 0.60:
        p -= (0.60 - overall_rate) * 0.80  # Brutal anchor penalty for bad track records
    else:
        p += (overall_rate - 0.60) * 0.20

    # Hidden character adjustments
    p += (fiab - 0.5) * 0.10

    # --------------------------------------------------------
    # 2. Advanced Multi-Factor Synergies & Thresholds
    # --------------------------------------------------------
    is_long = tiempo >= 8.0
    is_medium = 4.0 <= tiempo < 8.0
    is_short = tiempo < 4.0
    is_heavy = peso >= 15000.0

    # --- Weight Interactions ---
    factor_carga = peso / CAPACIDAD_MAX_PESO
    if is_heavy:
        p += (heavy_rate - 0.5) * 0.25
        p += (afin_pesada - 0.5) * 0.15
        if experiencia < 3.0:
            p -= 0.45  # Crucial rookie penalty for high-risk weight assignments
        p -= (impru * factor_carga * 0.40)  # Imprudencia + heavy cargo = extreme risk
    else:
        p += (light_rate - 0.5) * 0.10
        p -= (impru * 0.05)

    # --- Time & Fatigue Interactions ---
    factor_fatiga = min(tiempo / MAX_TIEMPO_RUTA, 1.0)
    if is_long:
        p += (long_rate - 0.5) * 0.25
        p += (afin_larga - 0.5) * 0.15
        if experiencia < 3.0:
            p -= 0.35  # Rookies fatigue and panic on massive runs
        p -= (factor_fatiga * impru * 0.50)  # Lethal synergy: Fatigue + Recklessness on long runs
    elif is_medium:
        p += (medium_rate - 0.5) * 0.10
    elif is_short:
        p += (short_rate - 0.5) * 0.10

    # Clamp the absolute mathematical boundaries before rolling chance
    return float(np.clip(p, 0.02, 0.98))

# ============================================================
# GENERATE DATASET
# ============================================================

rows = []
probs = []

# Define the boundaries of our historical Exogenous Shock
porcentaje_era_oscura = 0.25
filas_era_oscura = int(NUM_SAMPLES * porcentaje_era_oscura)

print(f"Generando {NUM_SAMPLES:,} muestras...")
print(f"-> Inyectando {filas_era_oscura:,} registros pertenecientes a la 'Era Oscura' del antiguo administrador.")

for i in range(NUM_SAMPLES):
    # Determine management context for this assignment
    es_era_oscura = (i < filas_era_oscura)

    driver = drivers_df.sample(1).iloc[0]
    
    # Pull dynamic parameters using correct column name strings
    tiempo, peso = generate_order_context(es_era_oscura, float(driver["experiencia_anios"]))

    p_success = compute_success_probability(driver, tiempo, peso)
    probs.append(p_success)
    
    # --------------------------------------------------------
    # 3. Variance Clamping (85% Logic, 15% Random Chaos)
    # --------------------------------------------------------
    pure_luck = random.random()
    final_score = (p_success * 0.85) + (pure_luck * 0.15)
    
    exito = 1 if final_score >= 0.50 else 0

    rows.append({
        "experiencia_anios": driver["experiencia_anios"],
        "total_ordenes": driver["total_ordenes"],
        "largas": driver["largas"],
        "largas_exitosas": driver["largas_exitosas"],
        "medias": driver["medias"],
        "medias_exitosas": driver["medias_exitosas"],
        "cortas": driver["cortas"],
        "cortas_exitosas": driver["cortas_exitosas"],
        "pesadas": driver["pesadas"],
        "pesadas_exitosas": driver["pesadas_exitosas"],
        "livianas": driver["livianas"],
        "livianas_exitosas": driver["livianas_exitosas"],
        "tiempo_efectivo_orden": round(tiempo, 2),
        "peso_orden": round(peso, 2),
        "exito": exito
    })

    if (i + 1) % 10000 == 0:
        print(f"   {i + 1:,} muestras guardadas...")

# ============================================================
# SAVE
# ============================================================

dataset_df = pd.DataFrame(rows)
dataset_df.to_csv(OUTPUT_DATASET, index=False)

print("\n=== PROCESO COMPLETADO EXITOSAMENTE ===")
print(f"Filas generadas de forma limpia: {len(dataset_df):,}")
print(f"Destino: {OUTPUT_DATASET}")

print("\nEstadísticas del Generador Modificado")
print("--------------------------------------")
print(f"Probabilidad Promedio : {np.mean(probs):.4f}")
print(f"Probabilidad Mínima   : {np.min(probs):.4f}")
print(f"Probabilidad Máxima   : {np.max(probs):.4f}")
print(f"Desviación Estándar   : {np.std(probs):.4f}")