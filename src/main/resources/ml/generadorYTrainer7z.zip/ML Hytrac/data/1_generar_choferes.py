import numpy as np
import pandas as pd

np.random.seed(42)

# Personalidades (sin cambiar las proporciones)
PERSONALIDADES = {
    "Veterano": {"prob": 0.25, "exp_mu": 26, "exp_std": 5, "exp_min": 18, "exp_max": 38, "fiab_alpha": 18, "fiab_beta": 3, "larga_mu": 0.90, "larga_std": 0.05, "pesada_mu": 0.82, "pesada_std": 0.08, "impru_alpha": 3, "impru_beta": 12},
    "Joven_Ambicioso":      {"prob": 0.20, "exp_mu": 4.5, "exp_std": 2, "exp_min": 1, "exp_max": 8, "fiab_alpha": 7, "fiab_beta": 4, "larga_mu": 0.87, "larga_std": 0.08, "pesada_mu": 0.77, "pesada_std": 0.10, "impru_alpha": 6, "impru_beta": 5},
    "Padre_Familia":  {"prob": 0.18, "exp_mu": 20, "exp_std": 5, "exp_min": 12, "exp_max": 28, "fiab_alpha": 15, "fiab_beta": 3, "larga_mu": 0.52, "larga_std": 0.10, "pesada_mu": 0.62, "pesada_std": 0.12, "impru_alpha": 2.5, "impru_beta": 11},
    "Gaucho":          {"prob": 0.12, "exp_mu": 17, "exp_std": 5, "exp_min": 10, "exp_max": 25, "fiab_alpha": 6, "fiab_beta": 5, "larga_mu": 0.94, "larga_std": 0.04, "pesada_mu": 0.75, "pesada_std": 0.09, "impru_alpha": 7, "impru_beta": 4.5},
    "Viejo_Grunyon":         {"prob": 0.10, "exp_mu": 29, "exp_std": 5, "exp_min": 22, "exp_max": 38, "fiab_alpha": 9, "fiab_beta": 5, "larga_mu": 0.42, "larga_std": 0.10, "pesada_mu": 0.88, "pesada_std": 0.07, "impru_alpha": 5.5, "impru_beta": 6},
    "Profesional_Corpo": {"prob": 0.08, "exp_mu": 14, "exp_std": 4, "exp_min": 8, "exp_max": 20, "fiab_alpha": 16, "fiab_beta": 3, "larga_mu": 0.82, "larga_std": 0.07, "pesada_mu": 0.70, "pesada_std": 0.10, "impru_alpha": 3, "impru_beta": 9},
    "Calculador_Audaz":     {"prob": 0.05, "exp_mu": 22, "exp_std": 5, "exp_min": 15, "exp_max": 30, "fiab_alpha": 10, "fiab_beta": 4, "larga_mu": 0.90, "larga_std": 0.06, "pesada_mu": 0.92, "pesada_std": 0.05, "impru_alpha": 5.5, "impru_beta": 5},
    "Novato":     {"prob": 0.02, "exp_mu": 1.5, "exp_std": 1, "exp_min": 0, "exp_max": 3, "fiab_alpha": 4, "fiab_beta": 5, "larga_mu": 0.65, "larga_std": 0.15, "pesada_mu": 0.55, "pesada_std": 0.15, "impru_alpha": 8, "impru_beta": 4}
}

def generar_flota(cantidad=500):
    data = []
    conteo = {nombre: 0 for nombre in PERSONALIDADES.keys()}
    
    for i in range(cantidad):
        # Elegir tipo de conductor
        tipos = list(PERSONALIDADES.keys())
        probs = [PERSONALIDADES[p]["prob"] for p in tipos]
        tipo = np.random.choice(tipos, p=probs)
        
        conteo[tipo] += 1
        id_conductor = f"{tipo}_{conteo[tipo]}"
        p = PERSONALIDADES[tipo]
        
        fila = {
            "conductor_id": id_conductor,
            "experiencia_anios": round(np.clip(np.random.normal(p["exp_mu"], p["exp_std"]), p["exp_min"], p["exp_max"]), 1),
            "fiabilidad": round(np.random.beta(p["fiab_alpha"], p["fiab_beta"]), 4),
            "afinidad_larga_distancia": round(np.clip(np.random.normal(p["larga_mu"], p["larga_std"]), 0.0, 1.0), 4),
            "afinidad_carga_pesada": round(np.clip(np.random.normal(p["pesada_mu"], p["pesada_std"]), 0.0, 1.0), 4),
            "factor_imprudencia": round(np.random.beta(p["impru_alpha"], p["impru_beta"]), 4)
        }
        data.append(fila)
    
    df = pd.DataFrame(data)
    
    # Guardar solo las columnas que querés
    df.to_csv("flota_choferes.csv", index=False, encoding='utf-8')
    
    print(f"Se generaron {cantidad} conductores")
    print("\nDistribución aproximada:")
    print(df["conductor_id"].str.split("_", expand=True)[0].value_counts())
    
    return df

# Ejecutar
if __name__ == "__main__":
    generar_flota(500)   # Cambia el número si querés más o menos